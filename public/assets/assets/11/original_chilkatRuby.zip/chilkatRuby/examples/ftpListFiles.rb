# file: ftpListFiles.rb

require '../chilkat'

# Ruby script to list files and sub-directories on an FTP server.

ftp = Chilkat::CkFtp2.new()
success = ftp.UnlockComponent("anything for 30-day trial")
if not success
	print "ftp component is locked!"
	exit
end

ftp.put_Username("***")
ftp.put_Password("***")
ftp.put_Hostname("***")

# Connect to the FTP server
success = ftp.Connect()
if not success
	ftp.SaveLastError("errorLog.txt")
	exit
end

# Set our ListPattern.
ftp.put_ListPattern("*")

# How many files and directories are there?
n = ftp.get_NumFilesAndDirs()

# List only the filenames and directory names...
for i in 0 .. n-1
	# Get the file or directory name:
	filename = ftp.getFilename(i)
	print filename + "\n"
end	

# List the filenames + size (in bytes) + last-mod date/time
sysTime = Chilkat::SYSTEMTIME.new()
for i in 0 .. n-1

	# Get the file or directory name:
	filename = ftp.getFilename(i)
	
	# Get the size of the file in bytes
	fileSize = ftp.GetSize(i)
	
	# Is it a file or directory?
	isDir = ftp.GetIsDirectory(i)
	
	# Get the last-mod date/time
	ftp.GetLastModifiedTime(i,sysTime)
	lastModTime = sysTime.wMonth.to_s()
	lastModTime = lastModTime + "/" + sysTime.wDay.to_s()
	lastModTime = lastModTime + "/" + sysTime.wYear.to_s()
	lastModTime = lastModTime + " " + sysTime.wHour.to_s()
	lastModTime = lastModTime + ":" + sysTime.wMinute.to_s()
	lastModTime = lastModTime + ":" + sysTime.wSecond.to_s()
	
	if (isDir) 
		print "[DIR] "
	end
	print filename + "(" + fileSize.to_s() + ") " + lastModTime + "\n"
	
end	

# Now get only files with a specific file extension...
ftp.put_ListPattern("*.php")

# Show the PHP files...
print "\n\nPHP Files Only:\n"
n = ftp.get_NumFilesAndDirs()
for i in 0 .. n-1
	# Get the file or directory name:
	filename = ftp.getFilename(i)
	print filename + "\n"
end	


# Disconnect from the FTP server.
ftp.Disconnect()
