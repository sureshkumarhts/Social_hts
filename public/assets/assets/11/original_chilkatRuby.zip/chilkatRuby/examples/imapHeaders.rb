# file: imapHeaders.rb

require '../chilkat'

# Ruby script to download email headers and get
# information about each email.

imap = Chilkat::CkImap.new()
success = imap.UnlockComponent("anything for 30-day trial")
if not success
	print "imap component is locked!"
	exit
end

# Connect to the IMAP server
success = imap.Connect("mail.chilkatsoft.com")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Login to the IMAP server.
success = imap.Login("***", "***")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Select an IMAP mailbox.
success = imap.SelectMailbox("Inbox")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Get a message set containing all the message IDs
# in the selected mailbox.
# Set bUid = false to return a set of sequence numbers.
# Set bUid = true to return a set of UIDs.
bUid = true
msgSet = imap.Search("ALL", bUid)
if (msgSet == nil) then
	imap.SaveLastError("errorLog.txt")
	exit
end

# Fetch the email headers into a bundle object.
bundle = imap.FetchHeaders(msgSet)
if (bundle == nil) then
	imap.SaveLastError("errorLog.txt")
	exit
end

# Loop over the bundle and display the From, Subject, and Attachment information.
for i in 0..(bundle.get_MessageCount-1)

    email = bundle.GetEmail(i)
    
    print "From: " + email.from + "\n"
    print "Subject: " + email.subject + "\n"
    
    # Get the To recipient information:
    for j in 0..(email.get_NumTo()-1)
    	print "To: " + email.toAddr(j) + "\n"
    end
    
    # Get the CC recipient information:
    for j in 0..(email.get_NumCC()-1)
    	print "CC: " + email.ccAddr(j) + "\n"
    end
    
    # Because we downloaded the email headers, the attachments are not
    # actually present in the email objects.  The email's get_NumAttachments method
    # will return 0.  The attachment information can be fetched with
    # imap.GetMailNumAttach, imap.GetMailAttachFilename, and imap.GetMailAttachSize.
    # When the full emails are downloaded, the email.get_NumAttachments and attachment
    # related methods return valid values.
    numAttach = imap.GetMailNumAttach(email)
    for j in 0..(numAttach-1)
    	fname = imap.mailAttachFilename(email,j)
    	sizeInBytes = imap.GetMailAttachSize(email,j)
    	
    	print "Attachment " + j.to_s() + ": " + fname + " - " + sizeInBytes.to_s() + " bytes\n"
    end  
end

# Logout
imap.Logout()

# Disconnect from the IMAP server.
imap.Disconnect()
