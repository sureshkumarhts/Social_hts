# file: importPfx.rb

require '../chilkat'

# Import a PFX (PKCS12) digital certificate with private key
# onto a Windows computer.
pfx = Chilkat::CkPfx.new()
pfx.UnlockComponent("anything for 30-day trial")

# If bMachineKeyset = true, the private key is save to the machine-wide protected
# store. Otherwise it is saved to the current logged-on user's protected store
# (and thus only available to the user account that did the import).
bMachineKeyset = false
# Set bLocalMachineCertStore = true to import the certificate to the local machine
# registry store, otherwise import to the current user registry store.
bLocalMachineCertStore = false
# Set bExportable = true to allow the private key to be re-exported.
bExportable = true
# Set bUseWarningDialog = true to turn on high security which causes the Windows
# operating system to issue a warning dialog whenever the private key is accessed.
# Programs running in ASP.NET or a Windows Service will hang if bUseWarningDialog = true
bUseWarningDialog = false

success = pfx.ImportPfxFile("tagtooga.pfx","secret",
    bMachineKeyset, bLocalMachineCertStore, bExportable, bUseWarningDialog)
    
if not success
	print "Failed to import PFX\n"
	pfx.SaveLastError("lastError.txt");
else
	print "Imported PFX!\n"
end
