# file: xmlSearchForContent.rb
# 
# Using the SearchForContent method...

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

# The Chilkat XML Ruby examples utilize these online XML data samples:
# http://www.chilkatsoft.com/xml-samples/bookstore.xml
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
# http://www.chilkatsoft.com/xml-samples/pigs.xml
# http://www.chilkatsoft.com/xml-samples/plants.xml
# http://www.chilkatsoft.com/xml-samples/japanese.xml
# http://www.chilkatsoft.com/xml-samples/hamlet.xml
    
xml = Chilkat::CkXml.new()
xml.LoadXmlFile("plants.xml")

# Find the plant having the common name Trillium
botName = Chilkat::CkString.new()
tag = "COMMON"
content = "Trillium"
start = nil
trillium = xml.SearchForContent(start,tag,content)
if (trillium != nil)
	# Move up to the parent node.
	trillium.GetParent2()
	# Print the BOTANICAL name
	trillium.GetChildContent("BOTANICAL",botName)
	print botName.getString() + "\n"
end

print "----\n"

# Find all plants requiring Sunny light.
# Iterate over all <LIGHT>Sunny</LIGHT> nodes in the XML document.
sunny = xml.SearchForContent(nil,"LIGHT","Sunny")
while (sunny != nil)
	# Get the parent.
	plant = sunny.GetParent()
	# Print the BOTANICAL name
	plant.GetChildContent("BOTANICAL",botName)
	print botName.getString() + "\n"
	
	# Get the next plant requiring Sunny light, starting the search after 
	# our current node.
	sunny = xml.SearchForContent(sunny,"LIGHT","Sunny")
end

