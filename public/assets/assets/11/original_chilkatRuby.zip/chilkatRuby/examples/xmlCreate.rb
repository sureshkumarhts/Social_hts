# file: xmlCreate.rb
# 
# Demonstrates how to create a simple XML document and save it to disk.

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

# The Chilkat XML Ruby examples utilize these online XML data samples:
# http://www.chilkatsoft.com/xml-samples/bookstore.xml
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
# http://www.chilkatsoft.com/xml-samples/pigs.xml
# http://www.chilkatsoft.com/xml-samples/plants.xml
# http://www.chilkatsoft.com/xml-samples/japanese.xml
# http://www.chilkatsoft.com/xml-samples/hamlet.xml
    
xml = Chilkat::CkXml.new()
xml.put_Tag("sample1")
xml.NewChild2("company","Chilkat Software Inc")
xml.NewChild2("city","Wheaton")
xml.NewChild2("year-founded","1998")
xml.NewChild2("industry","software")
xml.SaveXml("sample1.xml")

# The output of this progam has been uploaded to:
# http://www.chilkatsoft.com/xml-samples/sample1.xml
