# file: ZipPasswordProtected.rb

require '../chilkat'

# Create a password-protected zip.  (Password protection is the old-style
# Zip encryption.  It is somewhat insecure.  It is *not* AES encryption.

zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

zip.put_PasswordProtect(true)
zip.SetPassword("secret")

zip.NewZip("passwordProtected.zip")
zip.AppendFiles("exampleData/*",true)
zip.WriteZip()

