# file: xmpAddMetadata.rb

require '../chilkat'

# Add XMP metadata to a JPG or TIF image that does not yet have XMP metadata.
xmp = Chilkat::CkXmp.new()
success = xmp.UnlockComponent("Anything for 30-day trial")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# Both JPEG and TIFF files are supported.
success = xmp.LoadAppFile("images/dudeRuby.tif")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# Create a new XMP document.
xml = Chilkat::CkXml.new()
xmp.NewXmp(xml)

# Add some properties:
# <exif:PixelXDimension>432</exif:PixelXDimension>
# <exif:PixelYDimension>288</exif:PixelYDimension>

xmp.AddSimpleInt(xml,"exif:PixelXDimension",150)
xmp.AddSimpleInt(xml,"exif:PixelYDimension",150)

# Append it and save the image.  The "out.tif" file now contains XMP metadata.
xmp.Append(xml)
xmp.SaveAppFile("output/dudeRuby.tif")

# Save the XMP to an XML file so we can see what was embedded.
xml.SaveXml("output/newXmp.xml");

# This is the XMP document that is added to the TIF:
# <?xml version="1.0" encoding="utf-8" ?>
# 
# <x:xmpmeta xmlns:x="adobe:ns:meta/">
# <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
# <rdf:Description rdf:about="uuid:e402387b-3bf5-4c8e-b519-9c250de72c65" xmlns:exif="http://ns.adobe.com/exif/1.0/">
# <exif:PixelXDimension>150</exif:PixelXDimension>
# <exif:PixelYDimension>150</exif:PixelYDimension>
# </rdf:Description>
# </rdf:RDF>
# </x:xmpmeta>