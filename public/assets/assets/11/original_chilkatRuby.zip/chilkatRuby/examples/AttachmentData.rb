# file: AttachmentData.rb

# Ruby script to access email attachment contents in-memory.

require '../chilkat'

# Create an instance of the mailman object for reading POP3 email.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Create an email object and load it with a .eml file.
email = Chilkat::CkEmail.new()
email.LoadEml("testWithAttach.eml")

# Loop over the attachments.
numAttach = email.get_NumAttachments()
filename = Chilkat::CkString.new()
contentType = Chilkat::CkString.new()
textData = Chilkat::CkString.new()
binaryData = Chilkat::CkByteData.new()

for j in 0..(numAttach-1)
	# Get the attachment filename
	email.GetAttachmentFilename(j,filename)
	# Get the attachment content-type
	email.GetAttachmentContentType(j,contentType)
	
	# If the content type begins with "text/", such as text/plain or text/xml,
	# then extract the contents of the attachment into a CkString object.
	if contentType.beginsWith("text/") 
		# When fetching the content of a text attachment, you should only do so
		# if you know the character encoding of the data, such as utf-8 or
		# ANSI (which is typically iso-8859-1, a.k.a. latin1, or windows-1252 for
		# Western-European languages).  If you don't know the charset, you should
		# access the attachment data as binary to prevent the Chilkat component
		# from interpreting the character according to a character encoding.
		email.GetAttachmentString(j,"iso-8859-1",textData)
		
		# Print the filename and contents of the text file:
		print filename.getUtf8() + ":\n" + textData.getUtf8() + "\n-----\n\n"
		
	else
		# This is a binary attachment such as image/gif, application/octet-stream, video/quicktime, etc.
		email.GetAttachmentData(j,binaryData)
		
		print filename.getUtf8() + " (" + contentType.getUtf8() + ")\n"
		
		# print the decimal value of the 1st 2 bytes.
		print binaryData.getByte(0).to_s() + ", " + binaryData.getByte(1).to_s() + "\n"
		
		# Save this attachment to a file.
		binaryData.saveFile("binaryAttachments/" + filename.getUtf8())
	end
	
end

