# file: xmpGetProp.rb

require '../chilkat'

# Fetch the value of a simple string property from XMP metadata
# embedded in a JPG or TIF image file.
xmp = Chilkat::CkXmp.new()
success = xmp.UnlockComponent("Anything for 30-day trial")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

success = xmp.LoadAppFile("images/xmpExample.jpg")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# How many embedded XMP documents in the image file?
numEmbedded = xmp.get_NumEmbedded()
if (numEmbedded == 0) 
	print "This JPG does not have embedded XMP metadata\n"
	exit
end

# Retrieve the 1st XMP document as a CkXml object.
# (There is usually only a single embedded XMP)
xml = xmp.GetEmbedded(0)

# Fetch some simple properties:
propVal = xmp.simpleStr(xml,"Iptc4xmpCore:Location")
print "Location = " + propVal + "\n"

propVal = xmp.simpleStr(xml,"Iptc4xmpCore:CountryCode")
print "CountryCode = " + propVal + "\n"


