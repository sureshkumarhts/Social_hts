# file: ftpDownloadFile.rb

require '../chilkat'

# Ruby script to download a file from an FTP server.

ftp = Chilkat::CkFtp2.new()
success = ftp.UnlockComponent("anything for 30-day trial")
if not success
	print "ftp component is locked!"
	exit
end

ftp.put_Username("***")
ftp.put_Password("***")
ftp.put_Hostname("***")

# Connect to the FTP server
success = ftp.Connect()
if not success
	ftp.SaveLastError("errorLog.txt")
	exit
end

# Set our remote directory to "ftpTest"
success = ftp.ChangeRemoteDir("ftpTest")
if not success
	ftp.SaveLastError("errorLog.txt")
	exit
end

# Download a file.
localFile = "output/dude.gif"
remoteFile = "dude.gif"
success = ftp.GetFile(remoteFile,localFile)
if not success
	ftp.SaveLastError("errorLog.txt")
	exit
end

# Disconnect from the FTP server.
ftp.Disconnect()

print "FTP Download Successful!\n"
