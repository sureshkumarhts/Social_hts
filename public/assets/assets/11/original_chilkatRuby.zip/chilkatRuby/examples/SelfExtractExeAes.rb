# file: SelfExtractExeAes.rb

require '../chilkat'

# Create a 128-bit AES encrypted self-extracting EXE
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

# Set the Encryption property = 4, which indicates WinZip compatible AES encryption.
zip.put_Encryption(4)
# The key length can be 128, 192, or 256.
zip.put_EncryptKeyLength(128)
zip.SetPassword("secret")

# Calling NewZip does not actually create a file on disk.  The filename
# argument indicates the name of the zip file name to be created when
# WriteZip is called.  However, in this example, WriteExe is called instead,
# so the zip filename is meaningless.
zip.NewZip("notUsed.zip")
zip.AppendFiles("exampleData2/*",true)

# Write the self-extracting EXE
zip.WriteExe("example.exe")

