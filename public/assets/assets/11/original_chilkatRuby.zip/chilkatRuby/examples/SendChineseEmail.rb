# file: SendChineseEmail.rb

# This source file was saved using the GB2312 character encoding.

require '../chilkat'

# Ruby script to send email containing Chinese characters
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# SMTP hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a login, set login/password
# mailman.put_SmtpUsername("myUsername")
# mailman.put_SmtpPassword("myPassword")

# We need CkString to help with Chinese/GB2312
s1 = Chilkat::CkString.new()
s1.appendEnc("�������²�������������","GB2312")

# Create a new email object
email = Chilkat::CkEmail.new()
# Indicate that string input/output to the email object will be utf-8.
email.put_Utf8(true)
# Use Chinese characters in the subject, body, etc.
email.put_Subject(s1.getUtf8())
email.put_Body(s1.getUtf8())
email.put_From("Support <support@chilkatsoft.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

# Chilkat automatically recognizes the Chinese characters and chooses
# a typical charset for Chinese email: GB2312.
# Had the email contained characters not representable in GB2312 (such as Hebrew 
# characters) the component would have automatically chosen utf-8 as the encoding.

# The charset used throughout the entire email can be explicitly changed by setting
# the Charset property:
# email.put_Charset("utf-8")

# The following line of code is not required for this example.
# It saves the MIME source of the email so it can be reviewed
# in a text editor.
email.SaveEml("email.eml")
	
success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
