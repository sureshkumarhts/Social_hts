# file: imapSsl.rb

require '../chilkat'

# Ruby sample code to communicate with an IMAP server over SSL.

imap = Chilkat::CkImap.new()
success = imap.UnlockComponent("anything for 30-day trial")
if not success
	print "imap component is locked!"
	exit
end

# To connect via SSL, set the port to 993 and turn on the Ssl property:
imap.put_Ssl(true)
imap.put_Port(993)

# Connect to the IMAP server (using SSL)
success = imap.Connect("mail.chilkatsoft.com")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# The remainder of this example logs in, selects a mailbox,
# downloads the email and prints the From/Subject of each email.

# Login to the IMAP server.
success = imap.Login("***", "***")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Select an IMAP mailbox.
success = imap.SelectMailbox("Inbox")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Get a message set containing all the message IDs
# in the selected mailbox.
# Set bUid = false to return a set of sequence numbers.
# Set bUid = true to return a set of UIDs.
bUid = true
msgSet = imap.Search("ALL", bUid)
if (msgSet == nil) then
	imap.SaveLastError("errorLog.txt")
	exit
end

# Fetch the email into a bundle object.
bundle = imap.FetchBundle(msgSet)
if (bundle == nil) then
	imap.SaveLastError("errorLog.txt")
	exit
end

# Loop over the bundle and display the From and Subject.
for i in 0..(bundle.get_MessageCount-1)
    email = bundle.GetEmail(i)
    print "From: " + email.from + "\n"
    print "Subject: " + email.subject + "\n"
end

# Disconnect from the IMAP server.
# This example leaves the email on the IMAP server.
imap.Disconnect()
