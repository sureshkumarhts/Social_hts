# file: BuildHtmlEmail.rb

require '../chilkat'

# Example Ruby script to dynamically generate an HTML email 
# with embedded images and CSS style sheet and send.  	
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a login, set username/password
# mailman.put_SmtpUsername("myUsername")
# mailman.put_SmtpPassword("myPassword")

# Create a new email object.
email = Chilkat::CkEmail.new()

# Images that are embedded within an HTML email are reference by "CID" links.
# For example, an HTML IMG tag has a CID URL for the SRC attribute:
# <img src="CID:xyzabc">
# When creating an HTML email with embedded images using Chilkat, you first add
# each image to the email.  Embedded images (and style sheets) are considered
# "related" items.  They are not attachments and are not listed as files attached
# to an email because they are considered to be part of the HTML body.

# This email will need 5 related items (4 images and 1 style sheet)
cid1 = Chilkat::CkString.new()
cid2 = Chilkat::CkString.new()
cid3 = Chilkat::CkString.new()
cid4 = Chilkat::CkString.new()
cid5 = Chilkat::CkString.new()
    
css = "table#tscr {\n" +
"	border: 1px dashed;\n" +
"	margin: 8px;\n" +
"}\n" +
"table#tscr td {\n" +
"	font-family: Verdana;\n" +
"	font-size: 9pt;\n" +
"}"

# If the file on disk could not be found, or there were file permission issues,
# a false value is returned.  The CID is returned in the 2nd argument.
# This example will not check the return values...
b1 = email.AddRelatedFile("images/dudeJava.gif",cid1)
b2 = email.AddRelatedFile("images/dudePython.gif",cid2)
b3 = email.AddRelatedFile("images/dudePerl.gif",cid3)
b4 = email.AddRelatedFile("images/dudeRuby.gif",cid4)
    
# Our style sheet will be added from an in-memory string.
# The 1st argument is the "name" within the related part assigned to 
# the related part.  It should be any filename such that the file extension
# indicates the content-type (i.e. .gif, .jpg, .css, etc.)  It is not
# a file that exists on disk.  The charset indicates the charset to use
# for the text within the email.
email.AddRelatedString("sample.css",css,"iso-8859-1",cid5);

# Now that the CIDs are known, the HTML can be formed:
html = "<html>\n" +
"<head>\n" +
"<link rel=\"stylesheet\" type=\"text/css\" href=\"CID:" + cid5.getString() + "\" />\n" +
"</head>\n" +
"<body>\n" +
"<table id=\"tscr\" cellpadding=\"0\" cellspacing=\"10\">\n" +
"<tbody><tr>\n" +
"<td colspan=\"4\"><b>NEW:</b> Chilkat for Ruby Scripting</td>\n" +
"</tr><tr>\n" +
"<td><a href=\"http://www.chilkatsoft.com/java.asp\">Java</a><br><a href=\"http://www.chilkatsoft.com/java.asp\"><img src=\"CID:" + cid1.getString() + "\" border=\"0\"></a></td>\n" +
"<td><a href=\"http://www.chilkatsoft.com/perl.asp\">Perl</a><br><a href=\"http://www.chilkatsoft.com/perl.asp\"><img src=\"CID:" + cid3.getString() + "\" border=\"0\"></a></td>\n" +
"<td><a href=\"http://www.chilkatsoft.com/python.asp\">Python</a><br><a href=\"http://www.chilkatsoft.com/python.asp\"><img src=\"CID:" + cid2.getString() + "\" border=\"0\"></a></td>\n" +
"<td><a href=\"http://www.chilkatsoft.com/ruby.asp\">Ruby</a><br><a href=\"http://www.chilkatsoft.com/ruby.asp\"><img src=\"CID:" + cid4.getString() + "\" border=\"0\"></a></td>\n" +
"</tr>\n" +
"</tbody></table>\n" +
"</body>\n" +
"</html>"
	
# Add the HTML body.
email.SetHtmlBody(html)
    
# We still need a subject, and To/From
email.put_Subject("Sending HTML email from Ruby")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

# This line is not necessary.  It simply saves the email as a .eml 
# allowing you to examine the MIME source of the email in any text editor.
email.SaveEml("test.eml");

# Now send the HTML e-mail...
success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
