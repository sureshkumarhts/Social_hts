# file: htmlToXml.rb

require '../chilkat'

# Ruby script to convert HTML files to well-formed XML

htmlConv = Chilkat::CkHtmlToXml.new()
success = htmlConv.UnlockComponent("anything for 30-day trial")
if not success
	print "component is locked!"
	exit
end

htmlConv.ConvertFile("exampleData/test1.html","output/test1.xml")
htmlConv.ConvertFile("exampleData/test2.html","output/test2.xml")
htmlConv.ConvertFile("exampleData/test3.html","output/test3.xml")
