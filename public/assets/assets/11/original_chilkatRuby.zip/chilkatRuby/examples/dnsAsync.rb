# file: dnsAsync.rb

require '../chilkat'

# Asynchronous DNS query example program
socket = Chilkat::CkSocket.new()
success = socket.UnlockComponent("Anything for 30-day trial")
if not success
	socket.SaveLastError("errorLog.txt")
	exit
end

# Begin the DNS query.  The background thread will wait a max of 10 seconds
hostname = "www.chilkatsoft.com"
maxWaitMs = 10000
success = socket.AsyncDnsStart(hostname,maxWaitMs)
if not success
	socket.SaveLastError("errorLog.txt")
	exit
end

# Wait for the DNS query to complete.
# Your program may continue with other tasks while the DNS resolution is in progress...
while (not socket.get_AsyncDnsFinished())
	# The SleepMs method is provided for convenience.  (sleeps a number of milliseconds)
	socket.SleepMs(100)
end

# Display the result.
if (socket.get_AsyncDnsSuccess) 
	# The IP address is in asyncDnsResult (in XXX.XXX.XXX.XXX form)
	print hostname + ": " + socket.asyncDnsResult + "\n"
else
	# Failed or aborted.
	print socket.asyncDnsLog + "\n"
end

