# file: ZipReplaceData.rb

require '../chilkat'

# Open a zip, locate a file contained within it, replace the
# contents of the file, and save the zip.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

success = zip.OpenZip("exampleData.zip")
if success
	# The zip in this example contains these files and directories:
	# exampleData\
	# exampleData\hamlet.xml
	# exampleData\123\
	# exampleData\aaa\
	# exampleData\123\hello.txt
	# exampleData\aaa\banner.gif
	# exampleData\aaa\dude.gif
	# exampleData\aaa\xyz\	
	
	# Forward and backward slashes are equivalent and either can be used..
	zipEntry = zip.FirstMatchingEntry("*/hello.txt")
	if (zipEntry != nil) 
		# Replace the contents of hello.txt with something else.
		newContent = Chilkat::CkString.new()
		newContent.append("Goodbye!")
		zipEntry.ReplaceData(newContent)
		
		# Save the Zip with the new content.
		zip.WriteZipAndClose()
	else
		printf("Failed to find hello.txt!\n")
	end
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end

