# file: xmlEncryption.rb
# 
# Demonstrates how to 128-bit AES encrypt content in an XML document

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

# Some Chilkat XML Ruby examples utilize these online XML data samples:
# http://www.chilkatsoft.com/xml-samples/bookstore.xml
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
# http://www.chilkatsoft.com/xml-samples/pigs.xml
# http://www.chilkatsoft.com/xml-samples/plants.xml
# http://www.chilkatsoft.com/xml-samples/japanese.xml
# http://www.chilkatsoft.com/xml-samples/hamlet.xml
    
# The content of any node can be 128-bit AES encrypted. compressed.  
# a string that is the base64-encoded representation of the encrypted data.
xml = Chilkat::CkXml.new()
xml.put_Tag("encryptionExample")
xml.put_Content("This content is to be encrypted")
xml.EncryptContent("secretPassword")

# Print the XML document
strXml = Chilkat::CkString.new()
xml.GetXml(strXml)
printf "%s\n",strXml.getString()
# Prints
# <encryptionExample>0ZPEO/Cx1AzOupzei6GY/boc+P1ll9+lvCm+w1pE4mE=
# </encryptionExample>

# To restore the node's content, call DecryptContent:
# The password must match.
xml.DecryptContent("secretPassword")
xml.GetXml(strXml)
printf "%s\n",strXml.getString()
# Prints
# <encryptionExample>This content is to be encrypted</encryptionExample>

