# file: DecryptEmail.rb

# Ruby script to decrypt a digitally encrypted email.
#
# This example will load an encrypted email from a .eml file and demonstrate
# how to decrypt and examine the certificate used for encryption.
# Note: The private key is needed for decryption, so you will need
# to create your own encrypted .eml file and modify this code.
# There is already an example program at http://www.example-code.com/ruby/email.asp
# that shows how to create an encrypted .eml.

# (Chilkat email objects can also be created by downloading email from 
# a POP3 server, an IMAP server (using Chilkat IMAP) or loading
# directly from a MIME string.)

# When a Chilkat email object is created, the security layers 
# (signature and/or encryption) are automatically "unwrapped".  
# This happens when an email is loaded from a MIME string, a .eml file, 
# or downloaded from a POP3/IMAP server.

# The result is that your program is always working with an email 
# that is in an unsigned and unencrypted state.  There are properties and
# methods that allow you to determine if the email was originally signed
# and/or encrypted, whether it was successfully verified and/or decrypted,
# and what digital certificates were used.

require '../chilkat'

# Create an instance of the mailman object for unlocking
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Load an encrypted email from a .eml
email = Chilkat::CkEmail.new()
success = email.LoadEml("encrypted_email.eml")
if not success
	email.SaveLastError("lastError.txt");
else
	# Was this email encrypted?
	if (email.get_ReceivedEncrypted()) then
		print "This email was encrypted!\n"
		
		# Was it decrypted?  This check is only meaningful if the
		# email was encrypted (i.e. ReceivedEncrypted is true)
		if (email.get_Decrypted()) then
			print "The email was successfully decrypted\n"
			
			# Get the digital certificate used for encryption.
			cert = email.GetEncryptedByCert()
			
			# Show the certificate SubjectDN
			subjectDN = Chilkat::CkString.new()
			cert.get_SubjectDN(subjectDN)
			print "certificate SubjectDN:\n  [" + subjectDN.getString() + "]\n"
			
			# Is the certificate valid in all ways?
			if (cert.get_Revoked()) then
				print "Certificate is revoked!\n"
			end
			if (cert.get_Expired()) then
				print "Certificate is expired!\n"
			end
			if (!cert.get_SignatureVerified()) then
				print "Certificate's signature not verified!\n"
			end
			if (!cert.get_TrustedRoot()) then
				print "Certificate's root authority is not trusted!\n"
			end
			
		else
			print "Unable to decrypt this email!\n"
		end
	end
end