# file: xmpGetArray.rb

require '../chilkat'

# Fetch array property values (bag, alt, seq) in XMP metadata
# embedded in a JPG or TIF image file.
xmp = Chilkat::CkXmp.new()
success = xmp.UnlockComponent("Anything for 30-day trial")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

success = xmp.LoadAppFile("images/xmpExample.jpg")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# How many embedded XMP documents in the image file?
numEmbedded = xmp.get_NumEmbedded()
if (numEmbedded == 0) 
	print "This JPG does not have embedded XMP metadata\n"
	exit
end

# Retrieve the 1st XMP document as a CkXml object.
# (There is usually only a single embedded XMP)
xml = xmp.GetEmbedded(0)

# CkStringArray is an object containing a collection of strings.
strArray = Chilkat::CkStringArray.new()

# Fetch the array property values into strArray.
xmp.GetArray(xml,"dc:subject",strArray);

n = strArray.get_Count();
    
for i in 0..n-1
	print strArray.strAt(i) + "\n"
end
