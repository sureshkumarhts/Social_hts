# file: CheckMail.rb

# Ruby script to find out how many emails are in a POP3 mailbox.

require '../chilkat'

# Create an instance of the mailman object for reading POP3 email.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your POP3 server's hostname and login/password
mailman.put_MailHost("mail.chilkatsoft.com")
mailman.put_PopUsername("myLogin")
mailman.put_PopPassword("myPassword")

# How many messages are in the POP3 mailbox?
numEmails = mailman.CheckMail()
if numEmails == -1
	errorText = Chilkat::CkString.new()
	mailman.LastErrorText(errorText)
	print errorText.getUtf8()
else
	print "There are " + numEmails.to_s() + " mail messages in the mailbox\n"
end

