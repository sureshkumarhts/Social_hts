# file: omaDrmCreate.rb

require '../chilkat'

# Ruby example program to create an OMA DRM DCF file.    
omaDrm = Chilkat::CkOmaDrm.new()
omaDrm.UnlockComponent("anything for 30-day trial")
    
# Set the content type here:
omaDrm.set_ContentType("image/gif")
    
# Substitute your own URI here:
omaDrm.set_ContentUri("cid:my-text-20060925101425-1396302043@site.com")
    
# Substitute your own information here, but keep the
# Encryption-Method the same.
omaDrm.set_Headers("Encryption-Method: AES128CBC;padding=RFC2630" + 
		"\r\n" + "Content-Name: \"Orval\"" + 
		"\r\n" + "Content-Description: \"Orval\"" + 
		"\r\n" + "Content-Vendor: \"Orval\"" + 
		"\r\n" + "Icon-Uri: http://www.site.com/icons/orval2.dcf.png")
    
# You may set your initialization vector here:
omaDrm.SetEncodedIV("00010203040506070001020304050607", "hex")

# Your Base64-key for encryption can be set here:
omaDrm.set_Base64Key("BiVVJOQee6y4PWYL+fbvJA==")

# In this example, the content is a GIF image.
omaDrm.LoadUnencryptedFile("orval2.gif")

# Finally, write the DCF file:
omaDrm.CreateDcfFile("orval2.dcf")

