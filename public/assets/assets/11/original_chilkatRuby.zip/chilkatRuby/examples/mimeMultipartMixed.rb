# file: mimeMultipartMixed.rb

require '../chilkat'

# Demonstrates how to create a multipart/mixed MIME message
# with 2 sub-parts: a text/plain body and a GIF file attachment.
mime = Chilkat::CkMime.new()
mime.UnlockComponent("anything for 30-day trial")
	    
# Initialize to a multipart/mixed content-type:
mime.NewMultipartMixed()
		
# Create a text/plain MIME part.
textBody = Chilkat::CkMime.new()
textBody.SetBodyFromPlainText("This is the plain-text body!\nThank you.")
		
# Add it as a child to the multipart/mixed parent:
mime.AppendPart(textBody)
		
# Load a GIF file as a new sub-part:
mime.AppendPartFromFile("images/dudeRuby.gif")
		
# Chilkat automatically generates a unique boundary string.
# Need to change it?  Do this:
mime.put_Boundary("123--ABC--Blah-blah-blah")
		
# Print the MIME message:
print mime.mime() + "\n\n"
				
# Prints this MIME:
# 
# content-type: multipart/mixed;
# 	boundary="123--ABC--Blah-blah-blah"
# 
# This is a multi-part message in MIME format.
# 
# --123--ABC--Blah-blah-blah
# 
# This is the plain-text body!
# Thank you.
# --123--ABC--Blah-blah-blah
# content-disposition: attachment;
# 	 filename="dudeRuby.gif"
# content-transfer-encoding: base64
# content-type: image/gif;
# 	name="dudeRuby.gif"
# 
# R0lGODlhZABkAPf/AP////ry8vrx8Pnx8fnw8PXn5vXl5PTk4/Pg4PPf3/DX1+7Pz+3R0e3L
# y+zQz+vg4OvV1evKyuvDw+rk5Ojo6Oi/v+fBweW6uuS/v+O/v+Kvr+G/v+Gyst6kpNyWltui
# otqurdm4uNmMi9eendePj9eIh9bKyta1tdW+vtWTk9WSkdOPj9KmpdJ5eNGAgNCEhMy8vMp1
# ...
# OPmTL5ERCSRh53on0rlzwUcT7AZO8ctyUFat+gR4UEKNQyplMJkekRCqDxEgERAAOw==
# 
# --123--ABC--Blah-blah-blah--
# 