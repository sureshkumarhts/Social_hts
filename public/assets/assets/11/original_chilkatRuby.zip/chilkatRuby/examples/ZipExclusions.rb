# file: ZipExclusions.rb

require '../chilkat'

# Simple example showing how to Zip a directory tree
# excluding any files whose filenames match any one of a collection
# of patterns.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

# Create a CkStringArray object and fill it with
# filename patterns that should not be included in the .zip
sa = Chilkat::CkStringArray.new()
sa.Append("*.obj")
sa.Append("*.pch")
sa.Append("*.trg")
sa.Append("*.tmp")
sa.Append("*.exp")
sa.Append("*.idb")
# ... any number of exlude patterns can be added...

# Set the exclusions
zip.SetExclusions(sa)

# Create a .zip from a directory tree.  Any files matching
# any one of the exlusion patterns will *not* be included.
zip.NewZip("xmp.zip")

# To test on your computer, modify this example
# to zip a directory tree that exists on your system.
zip.AppendFiles("c:/obj/ChilkatXmp/*",true)
zip.WriteZip()

