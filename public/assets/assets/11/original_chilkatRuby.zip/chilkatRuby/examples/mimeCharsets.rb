# file: mimeCharsets.rb

require '../chilkat'

# Chilkat MIME makes it easy to create MIME using different charsets.
mime = Chilkat::CkMime.new()
mime.UnlockComponent("anything for 30-day trial")

mime.put_Charset("iso-8859-1")
mime.put_Encoding("quoted-printable")

# Add some Danish text to make it interesting:
mime.SetBodyFromPlainText("Jeg kan spise glas, det g�r ikke ondt p� mig.")

# Add a header with some Danish chars...
mime.SetHeaderField("subject","g�r ikke ondt p� mig")
mime.SetHeaderField("junk1","g�r p�")
mime.SetHeaderField("junk2","abc 123")

print mime.mime() + "\n\n"

# We get the following MIME.  Notice that the headers are
# Q-encoded where necessary:
#		    
# content-transfer-encoding: quoted-printable
# content-type: text/plain;
#	 charset="iso-8859-1"
# subject: =?iso-8859-1?Q?g=F8r_ikke_ondt_p=E5_mig?=
# junk1: =?iso-8859-1?Q?g=F8r_p=E5?=
# junk2: abc 123
#
# Jeg kan spise glas, det g=F8r ikke ondt p=E5 mig.



# Change the charset to utf-8.  With utf-8, each 8bit Danish character
# will be encoded in two bytes rather than one.
mime.put_Charset("utf-8")
print mime.mime()

# Prints this:
# 		
# content-transfer-encoding: quoted-printable
# subject: =?utf-8?Q?g=C3=B8r_ikke_ondt_p=C3=A5_mig?=
# junk1: =?utf-8?Q?g=C3=B8r_p=C3=A5?=
# junk2: abc 123
# content-type: text/plain;
# 	 charset="utf-8"
# 
# Jeg kan spise glas, det g=C3=B8r ikke ondt p=C3=A5 mig.
		



# -----------------------------------------		
# Chilkat supports all major international charsets, including
# Asian languages.
