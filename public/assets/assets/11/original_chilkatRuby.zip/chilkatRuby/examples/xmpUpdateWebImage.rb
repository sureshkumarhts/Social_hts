# file: xmpUpdateWebImage.rb

require '../chilkat'

# Updates the XMP metadata for a JPG at a URL.
# The JPG is downloaded using HTTP (directly into memory).
# The modified JPG is uploaded via FTP.
httpObj = Chilkat::CkHttp.new()
httpObj.UnlockComponent("Anything for 30-day trial")

# Create a buffer that will hold the JPG file data.
# We never actually write a JPG file to the local system, everything occurs in memory.
byteData = Chilkat::CkByteData.new()

# Download the JPG into the byte buffer.
success = httpObj.QuickGet("http://www.chilkatsoft.com/images/xmpExample2.jpg",byteData)
if not success
	httpObj.SaveLastError("errorLog.txt")
	exit
end

xmp = Chilkat::CkXmp.new()
success = xmp.UnlockComponent("Anything for 30-day trial")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# The 2nd argument indicates that a JPG is being loaded.
success = xmp.LoadFromBuffer(byteData,"jpg")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# How many embedded XMP documents in the JPG?
numEmbedded = xmp.get_NumEmbedded()
if (numEmbedded == 0) 
	print "This JPG does not have embedded XMP metadata\n"
	exit
end

# Retrieve the 1st XMP document as a CkXml object.
# (There is usually only a single embedded XMP)
xml = xmp.GetEmbedded(0)

# CkStringArray is an object containing a collection of strings.
strArray = Chilkat::CkStringArray.new()

# Fetch the dc:subject array property values into strArray.
xmp.GetArray(xml,"dc:subject",strArray);

# Remove a few values:
strArray.Remove("moon")
strArray.Remove("night")
strArray.Remove("blue")

# Add a few additional values.
# Make sure duplicates are not added, and sort the final array.
strArray.put_Unique(true)
strArray.Append("dawn")
strArray.Append("ancient")
strArray.Append("historical")
ascending = true
strArray.Sort(ascending)

# Print the array values...
n = strArray.get_Count();
for i in 0..n-1
	print strArray.strAt(i) + "\n"
end

# Update the dc:subject XMP metadata.
# The AddArray method replaces the property if it already exists.
xmp.AddArray(xml,"bag","dc:subject",strArray)

# Write the updated JPG to a byte buffer
xmp.SaveToBuffer(byteData)


# Upload the JPG back to the web server using FTP:
ftp = Chilkat::CkFtp2.new()
ftp.UnlockComponent("Anything for 30-day trial")

ftp.put_Hostname("ftp.chilkatsoft.com")
ftp.put_Username("myLogin")
ftp.put_Password("myPassword")

success = ftp.Connect()
if not success
	ftp.SaveLastError("ftpErrorLog.txt")
	exit
end

success = ftp.ChangeRemoteDir("temp")
if not success
	ftp.SaveLastError("ftpErrorLog.txt")
	exit
end

# Upload the JPG data to http://www.chilkatsoft.com/temp/updated.jpg
success = ftp.PutFileFromBinaryData("updated.jpg",byteData)
if not success
	ftp.SaveLastError("ftpErrorLog.txt")
	exit
end

ftp.Disconnect()

