# file: imapDeleteMail.rb

require '../chilkat'

# Ruby sample program to delete mail from an IMAP mailbox.

imap = Chilkat::CkImap.new()
success = imap.UnlockComponent("anything for 30-day trial")
if not success
	print "imap component is locked!"
	exit
end

# Connect to the IMAP server
success = imap.Connect("mail.chilkatsoft.com")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Login to the IMAP server.
success = imap.Login("***", "***")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Select an IMAP mailbox.
success = imap.SelectMailbox("Inbox")
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

# Create a set of UIDs for all emails having the substring 
# "SPAM" in the subject
bUid = true
msgSet = imap.Search("SUBJECT \"SPAM\"", bUid)
if (msgSet == nil) then
	imap.SaveLastError("errorLog.txt")
	exit
end

# Mark all messages in the message set for deletion
# Set the flag to 1 for delete, set the flag to 0 for un-delete.
# The messages are not deleted until the mailbox is expunged and closed.
success = imap.SetFlags(msgSet,"Deleted",1)
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

success = imap.ExpungeAndClose()
if not success
	imap.SaveLastError("errorLog.txt")
	exit
end

imap.Logout()
imap.Disconnect()
