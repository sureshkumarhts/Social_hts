# file: CreateEncryptedEml.rb

require '../chilkat'

# How to create an encrypted EML (email) file in Ruby using the Chilkat email module.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Create a simple email
email = Chilkat::CkEmail.new()
email.put_Subject("Encrypted email in Ruby")
email.put_Body("Encrypted email in Ruby")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a single recipient
# It is the digital certificate of the recipient that is used to encrypt.
email.AddTo("TagTooga","admin@tagtooga.com")

# There are a number of ways to send digitally encrypted email using Chilkat.
# This example demonstrates the easiest (other examples will explore
# some of the other possibilities).
# To send an encrypted email, you will first need the digital certificate
# for the recipient. The email address in the certificate should match
# the recipient's email address.  You do not need the private key to send
# encrypted email: only the public-key is required.  The recipient however,
# must have his/her certificate installed with private key in order to decrypt.
# 
# If you have the digital certificate in a .cer file, double-click on it from
# Windows Explorer and install the certificate in the default location.  
# Chilkat should now be able to locate it.  You only need to set the SendEncrypted
# property = true to send encrypted email.  
#
# That's it.  When RenderToMime is called, it will locate the certificate matching
# the recipient's email address, encrypt the email (including all attachments) and 
# send it.
email.put_SendEncrypted(true)

mimeStr = Chilkat::CkString.new()
# The RenderToMime method renders the email according to the property settings
# of the email and mailman objects.
success = mailman.RenderToMime(email,mimeStr)
if not success
	mailman.SaveLastError("lastError.txt");
else
	# Convert line endings from CRLF to bare LF's
	mimeStr.toLF()
	# Save the MIME string to a file.
	aFile = File.new("encrypted_email.eml", "w")
	aFile.write(mimeStr.getString())
	aFile.close
end
