# file: UnzipMatching.rb

require '../chilkat'

# Unzip all files matching a wildcarded pattern.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

# Open an already-existing zip
success = zip.OpenZip("exampleData.zip")
if success
	# The zip in this example contains these files and directories:
	# exampleData\
	# exampleData\hamlet.xml
	# exampleData\123\
	# exampleData\aaa\
	# exampleData\123\hello.txt
	# exampleData\aaa\banner.gif
	# exampleData\aaa\dude.gif
	# exampleData\aaa\xyz\	

	# Unzip all .gif files into the "images_2" subdirectory
	# If verbose is set to true, the last-error information will contain
	# a log of each file tested and whether it matched or not.
	# The UnzipMatchingInto method discards the path information associated
	# with each matching file within the zip and unzips each file
	# directly into the directory specified.
	verbose = false
	numUnzipped = zip.UnzipMatchingInto("images_2","*.gif",verbose)
	printf("numUnzipped = %d\n",numUnzipped)

	# If UnzipMatching is called (instead of UnzipMatchingInto), each matching
	# file is unzipped to a directory consistent with the path information stored
	# within the zip.  For example, "exampleData\aaa\dude.gif" is unzipped to
	# "images_3\exampleData\aaa\dude.gif"
	numUnzipped = zip.UnzipMatching("images_3","*.gif",verbose)
	printf("numUnzipped = %d\n",numUnzipped)
	
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end
