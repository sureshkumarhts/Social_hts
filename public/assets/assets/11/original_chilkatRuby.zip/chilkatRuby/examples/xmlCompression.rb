# file: xmlCompression.rb
# 
# Demonstrates how to Zip compress parts or all of an XML document.

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

# Some Chilkat XML Ruby examples utilize these online XML data samples:
# http://www.chilkatsoft.com/xml-samples/bookstore.xml
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
# http://www.chilkatsoft.com/xml-samples/pigs.xml
# http://www.chilkatsoft.com/xml-samples/plants.xml
# http://www.chilkatsoft.com/xml-samples/japanese.xml
# http://www.chilkatsoft.com/xml-samples/hamlet.xml
    
# The content of any node can be Zip compressed.  The result is 
# a string that is the base64-encoded representation of the compressed binary data.
xml = Chilkat::CkXml.new()
xml.put_Tag("compressionExample")

# Create a long string...
strContent = Chilkat::CkString.new()
for i in 0 .. 100
	strContent.append("abc 123 Chilkat Software Inc Ruby XML Scripting ")
end
xml.put_Content(strContent.getString())

# Zip compress the node's content.
xml.ZipContent()
xml.SaveXml("compressed1.xml")

# Print the XML document
strXml = Chilkat::CkString.new()
xml.GetXml(strXml)
printf "%s\n",strXml.getString()
# Prints
# <?xml version="1.0" encoding="utf-8" ?>
# <compressionExample><![CDATA[7cq9CYAwFEbRVb4V1BGsBG1MY/sS/AlKlBARt3cNi3vqYz6oqhu1Wzx2K3LnUh7Ls7oUNN7+
# 1TT0ciHHq8S0yvh8Pp/P5/P5fD6fz+fz+fwf/w8=
# ]]></compressionExample>

# To unzip, call UnzipContent:
xml.UnzipContent()
xml.SaveXml("uncompressed1.xml")



# It is possible to zip and unzip XML sub-trees:
# We'll use pigs.xml as an example.  Each pig's record will be compressed...
xml.LoadXmlFile("pigs.xml")
#xml.GetXml(strXml)
#printf "%s\n",strXml.getString()

# Iterate over the child nodes and compress each "animal" subtree:
n = xml.NumChildrenHavingTag("animal")
for i in 0 .. n-1
	subtree = xml.GetNthChildWithTag("animal",i)
	subtree.GetChildContent("name",strContent)
	subtree.ZipTree()
	# Add the pig's name as an attribute of the zipped XML sub-tree
	subtree.AddAttribute("name",strContent.getString())
end
xml.SaveXml("pigsCompressed.xml")
xml.GetXml(strXml)
printf "%s\n",strXml.getString()
# Prints
# <?xml version="1.0" encoding="utf-8" ?>
# 
# <pig-rescue>
# <image-base>images</image-base>
# <animal name="Molly II">
# <![CDATA[ZVPBitwwDD3vwPyD2ENPs/G0py51DW1h6RYWCi30uDixErvjWMZ2OuTvK8edssvkZL8nPT1L
# yn4ndXCz9mq/kzni4DCrSAV69H6F6CYpLjBHlDWi+qKLXd/oSPlDhq+YjBQbznzQM6onqqmP
# j1JsV4Z7l4pVD9inRaf1AG/v799L0VCmXbgzuqD6pkPj3x2PRykuMEeMiWb15IzxCJ/+YCfF
# hjAzYTCYIEe93gVcCqaPtyvmW/UgReNahZH++RrYE9Rs0BC9HhDOFhOCDkDeHMB5DzNfrDZQ
# iOp5hdaj3O138Oq7+WnxQsK5ymT0hrVHNIwbSLowQYs3gLpA4fCA555SqL31WK40b+CXxQDN
# 7FlnGGlhIU6mwF4RT81nZqlKV0kKbVasBzTClUtbO+R678LEbiyBcQYCT3nihFwwRrZLAXp+
# KQx07uAHq7rMt8wVy+FackyOu9vKbpLenZDdEDcuTEBL9QuvViVSGmxFq2XPr5rwWjdq09XR
# 87x4btENZUltBZxHNdeuPBfb/Y68mBvElME8JBeLo6A+80hPbW9fwhw16HZsnXXNxnedawEp
# LiwHihdVxf+/4y8=
# ]]></animal>
# <animal name="Nigel">
# <![CDATA[bVNNb9swDD0nQP4D0XNq1RswrIAnINsOWYENAdKeB1mmba2yJOgDrvfrR9lJkWY9We+Renyk
# 6M26EkYNQvPNugoOpcLAnY1Qo9YTONVV7ExTRpwc8r1NAeGQQzMm3ogB+S/Voa7YfCauVj72
# /CEZ3EJ5f19WbGEopMxtIyLyXepSiOfwmaWE1tuBf/WIDfqKzYjYDg1hCE5MtwZTRP/lZsJw
# ...
# 3d+gmXkUz5V4Ja8P086sntUTItXjs/wH
# ]]></animal>
# </pig-rescue>


# A sub-tree can be unzipped by calling UnzipTree:
xml.LoadXmlFile("pigsCompressed.xml")
# Find the pig named "Molly II"
molly = xml.SearchForAttribute(nil,"animal","name","Molly II")
# Unzip molly's sub-tree
molly.UnzipTree()
# Print molly's child tags and content:
n = molly.get_NumChildren()
strTag = Chilkat::CkString.new()
for i in 0 .. n-1
	molly.GetChildTag(i,strTag)
	molly.GetChildContentByIndex(i,strContent)
	strContent.replaceAllOccurances("\n"," ")
	strContent.trimInsideSpaces()
	printf "%s: %s\n",strTag.getString(),strContent.getString()
end

