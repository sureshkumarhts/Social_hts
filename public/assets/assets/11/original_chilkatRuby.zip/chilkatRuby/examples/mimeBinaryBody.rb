# file: mimeBinaryBody.rb

require '../chilkat'

# A MIME body can be loaded with the contents of a file.
# The Chilkat MIME component automatically maps the file extension
# to a content-type.  If no mapping is found, the content-type is
# set to application/octet-stream and the content-transfer-encoding
# is set to base64.  Otherwise the content-transfer-encoding
# is set to what is appropriate for the file contents.
# 
# Note: content-transfer-encoding and content-type can be updated
# after loading the body from a file by simply setting the ContentType
# and Encoding properties.

		
mime = Chilkat::CkMime.new()
mime.UnlockComponent("anything for 30-day trial")
	    
# Load the MIME body with a GIF file.
mime.SetBodyFromFile("images/dudeRuby.gif")
		
# Print the MIME:
print mime.mime() + "\n\n"

# Prints this:
# content-disposition: attachment;
# 	 filename="dudeRuby.gif"
# content-transfer-encoding: base64
# content-type: image/gif;
# 	name="dudeRuby.gif"
# 
# R0lGODlhZABkAPf/AP////ry8vrx8Pnx8fnw8PXn5vXl5PTk4/Pg4PPf3/DX1+7Pz+3R0e3L
# y+zQz+vg4OvV1evKyuvDw+rk5Ojo6Oi/v+fBweW6uuS/v+O/v+Kvr+G/v+Gyst6kpNyWltui
# otqurdm4uNmMi9eendePj9eIh9bKyta1tdW+vtWTk9WSkdOPj9KmpdJ5eNGAgNCEhMy8vMp1
# ...
# OPmTL5ERCSRh53on0rlzwUcT7AZO8ctyUFat+gR4UEKNQyplMJkekRCqDxEgERAAOw==


		
# Remove the "name" attribute from the content-type:
mime.put_Name("")
# Remove the "filename" attribute from the content-disposition:
mime.put_Filename("")
# Remove the content-disposition altogether:
mime.put_Disposition("")
		
# Print the MIME:
print mime.mime() + "\n\n"

# Prints this:
# content-transfer-encoding: base64
# content-type: image/gif
# 
# R0lGODlhZABkAPf/AP////ry8vrx8Pnx8fnw8PXn5vXl5PTk4/Pg4PPf3/DX1+7Pz+3R0e3L
# y+zQz+vg4OvV1evKyuvDw+rk5Ojo6Oi/v+fBweW6uuS/v+O/v+Kvr+G/v+Gyst6kpNyWltui
# otqurdm4uNmMi9eendePj9eIh9bKyta1tdW+vtWTk9WSkdOPj9KmpdJ5eNGAgNCEhMy8vMp1
# ...
# OPmTL5ERCSRh53on0rlzwUcT7AZO8ctyUFat+gR4UEKNQyplMJkekRCqDxEgERAAOw==

