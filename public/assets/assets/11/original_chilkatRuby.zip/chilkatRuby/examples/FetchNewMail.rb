# file: FetchNewMail.rb

# Ruby script to fetch new email that has not yet been downloaded.

# There is nothing in the POP3 protocol that allows for "new" or "unread" emails
# to be downloaded.  The read/unread status of an email is not available via the
# POP3 protocol.  This means programs must save the read/unread status locally.

require '../chilkat'

# Create an instance of the mailman object for reading POP3 email.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your POP3 server's hostname and login/password
mailman.put_MailHost("mail.chilkatsoft.com")
mailman.put_PopUsername("myLogin")
mailman.put_PopPassword("myPassword")

# Assume that the already-seen UIDLs are saved to a .txt file
# containing one UIDL per line.
# Load this file into our already-seen CkStringArray
saAlreadySeen = Chilkat::CkStringArray.new()
saAlreadySeen.LoadFromFile("alreadySeenUidls.txt")

# Get the UIDLs for the mail in a POP3 mailbox.
# sa is a Chilkat::CkStringArray
sa = mailman.GetUidls()
if sa == nil
	errorText = Chilkat::CkString.new()
	mailman.LastErrorText(errorText)
	print errorText.getUtf8()
else
	# Build a set of UIDLs that haven't yet been downloaded.
	saUidlsToDownload = Chilkat::CkStringArray.new()
	
	# For each UIDL on the POP3 server, if it's not present in saAlreadySeen,
	# add it to saUidlsToDownload
	uidl = Chilkat::CkString.new()
	numUidls = sa.get_Count()
	for i in 0..(numUidls-1)
		sa.GetString(i,uidl)
		if (!saAlreadySeen.Contains(uidl.getString()))
			saUidlsToDownload.Append(uidl.getString())
		end
	end
	
	# Download the emails in saUidlsToDownload
	if (saUidlsToDownload.get_Count() > 0) 
		bundle = mailman.FetchMultiple(saUidlsToDownload)
		if bundle == nil 
			errorText = Chilkat::CkString.new()
			mailman.LastErrorText(errorText)
			print errorText.getUtf8()
		else
			# Update alreadySeenUidls.txt with the exact set of UIDLs on the
			# POP3 server so that the next time this is run, only the
			# new emails will be downloaded.
			sa.SaveToFile("alreadySeenUidls.txt")
			
			# We can now process the downloaded emails in any way we like...
			numMessages = bundle.get_MessageCount()

			# This loop prints the subject and From for each email...
			subject = Chilkat::CkString.new()
			from = Chilkat::CkString.new()
			for i in 0..(numMessages-1)
				email = bundle.GetEmail(i)			
				email.get_Subject(subject)
				email.get_From(from)
				print "From:    " + from.getUtf8() + "\n"
				print "Subject: " + subject.getUtf8() + "\n\n"
			end
		end
	end
end
