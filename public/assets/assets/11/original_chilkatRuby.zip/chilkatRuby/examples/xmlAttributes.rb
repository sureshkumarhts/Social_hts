# file: xmlAttributes.rb
# 
# Demonstrates working with XML attributes.

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

# Some Chilkat XML Ruby examples utilize these online XML data samples:
# http://www.chilkatsoft.com/xml-samples/bookstore.xml
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
# http://www.chilkatsoft.com/xml-samples/pigs.xml
# http://www.chilkatsoft.com/xml-samples/plants.xml
# http://www.chilkatsoft.com/xml-samples/japanese.xml
# http://www.chilkatsoft.com/xml-samples/hamlet.xml
    
# Create a new XML document (in-memory) to begin working with attributes...
xml = Chilkat::CkXml.new()
xml.put_Tag("example")

bookNode = xml.NewChild("book","Water for Elephants: A Novel")

# If we save the XML to a file, we have this:
# <?xml version="1.0" encoding="utf-8" ?>
# <example>
# <book>Water for Elephants: A Novel</book>
# </example>
xml.SaveXml("book0.xml")

# Add a few attributes
bookNode.AddAttribute("author","Sara Gruen")
bookNode.AddAttribute("price","$14.37")
bookNode.AddAttribute("numReviews","154")
xml.SaveXml("book1.xml")
# We now have this:
# <?xml version="1.0" encoding="utf-8" ?>
# <example>
# <book author="Sara Gruen" price="$14.37" numReviews="154">Water for Elephants: A Novel</book>
# </example>

# How many attributes?
print "Number of attributes = " + String(bookNode.get_NumAttributes()) + "\n"

# Remove an attribute by name
bookNode.RemoveAttribute("price")
print "Number of attributes = " + String(bookNode.get_NumAttributes()) + "\n"

# Attribute exists?
if bookNode.HasAttribute("author") then
	print "Has author attribute!\n"
else
	print "Does not have author attribute!\n"
end

# Attribute with value exists?
if bookNode.HasAttrWithValue("author","Sara Gruen") then
	print "Has author/Sara Gruen attribute!\n"
else
	print "Does not have author/Sara Gruen attribute!\n"
end

# Get attribute value by name
authorName = Chilkat::CkString.new()
bookNode.GetAttrValue("author",authorName)
print "Author's name is " + authorName.getString() + "\n"

# Iterate over attributes, getting names and values.
attrName = Chilkat::CkString.new()
attrValue = Chilkat::CkString.new()

print "--------------------------\n"
numAttr = bookNode.get_NumAttributes()
for i in 0 .. numAttr-1
	bookNode.GetAttributeName(i,attrName)
	bookNode.GetAttributeValue(i,attrValue)
	print attrName.getString() + ": " + attrValue.getString() + "\n"
end

# Update the value of an existing attribute
bookNode.UpdateAttribute("price","$15.37")

# Insert a new attribute, or update if already exists.
bookNode.AddOrUpdateAttribute("price","$12.99")

# Add an integer amount to an integer attribute:
# In this case, numReviews was 154.  After this method call it will be 155.
bookNode.AddToAttribute("numReviews","1")

# Remove all attributes from a node
bookNode.RemoveAllAttributes()


