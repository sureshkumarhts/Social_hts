# file: Dsn.rb

# Ruby script to parse a Delivery Status Notification (DSN) email message.

require '../chilkat'

# Create an instance of the mailman object for unlocking purposes.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Load a delivery status notification email.
email = Chilkat::CkEmail.new()
success = email.LoadEml("dsnSamples/dsnSample2.eml")
if not success
	email.SaveLastError("lastError.txt");
else
	# First, check to see if this is a multipart/report.  
	# DSN messages are always multipart/report at the outermost MIME layer.
	if (email.IsMultipartReport()) then
		print "Parsing a DSN email!\n"
		
		
		
		
		
		
	else
		print "This is not a DSN email.\n"
	end
	
end


