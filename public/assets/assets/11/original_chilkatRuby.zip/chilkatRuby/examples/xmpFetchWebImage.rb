# file: xmpFetchWebImage.rb

require '../chilkat'

# Download a JPG from a URL into a CkByteData object.
# Fetch XMP metadata information from the JPG.
# Note: The JPG is never written to a file, it is downloaded
# into memory, and the JPG is opened from memory.
httpObj = Chilkat::CkHttp.new()
httpObj.UnlockComponent("Anything for 30-day trial")

byteData = Chilkat::CkByteData.new()
success = httpObj.QuickGet("http://www.chilkatsoft.com/images/xmpExample.jpg",byteData)
if not success
	httpObj.SaveLastError("errorLog.txt")
	exit
end

xmp = Chilkat::CkXmp.new()
success = xmp.UnlockComponent("Anything for 30-day trial")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# The 2nd argument indicates that a JPG is being loaded.
success = xmp.LoadFromBuffer(byteData,"jpg")
if not success
	xmp.SaveLastError("errorLog.txt")
	exit
end

# How many embedded XMP documents in the JPG?
numEmbedded = xmp.get_NumEmbedded()
if (numEmbedded == 0) 
	print "This JPG does not have embedded XMP metadata\n"
	exit
end

# Retrieve the 1st XMP document as a CkXml object.
# (There is usually only a single embedded XMP)
xml = xmp.GetEmbedded(0)

# CkStringArray is an object containing a collection of strings.
strArray = Chilkat::CkStringArray.new()

# Fetch the array property values into strArray.
xmp.GetArray(xml,"dc:subject",strArray);

n = strArray.get_Count();
    
for i in 0..n-1
	print strArray.strAt(i) + "\n"
end
