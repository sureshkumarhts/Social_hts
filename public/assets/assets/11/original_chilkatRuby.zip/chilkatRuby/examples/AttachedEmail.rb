# file: AttachedEmail.rb

# Forwarded emails contain the original email(s) in message/rfc822 sub-parts.
# The Chilkat Email API provides a method for extracting an attached message
# and returning it as an email object.  It is possible for an email to contain
# an attached message, which in turn contains another, etc.   There is no limitation
# on the number of possible recursive nesting levels.

require '../chilkat'

# Create an instance of the mailman object for reading POP3 email.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Load an email with an attached message from a .eml file.
email = Chilkat::CkEmail.new()
success = email.LoadEml("forwardedEmail.eml")
if not success
	email.SaveLastError("lastError.txt");
else
	numAttachedMsgs = email.get_NumAttachedMessages()
	
	subject = Chilkat::CkString.new()
	fromAddr = Chilkat::CkString.new()
	
	for i in 0..(numAttachedMsgs-1)
		attachedEmail = email.GetAttachedMessage(i)
		
		# Do a few things with the attached email, for demonstration purposes.
		attachedEmail.SaveEml("attachedEmail_" + i.to_s() + ".eml")
		
		attachedEmail.get_Subject(subject)
		attachedEmail.get_FromAddress(fromAddr)
		
		print "Attached Email: " + i.to_s() + "\n"
		print "    Subject: " + subject.getUtf8() + "\n"
		print "    From: " + fromAddr.getUtf8() + "\n\n"
	end	
end


