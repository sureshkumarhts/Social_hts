# file: InflateToBinary.rb

require '../chilkat'

# Inflate binary data into memory.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

success = zip.OpenZip("exampleData.zip")
if success
	# The zip in this example contains these files and directories:
	# exampleData\
	# exampleData\hamlet.xml
	# exampleData\123\
	# exampleData\aaa\
	# exampleData\123\hello.txt
	# exampleData\aaa\banner.gif
	# exampleData\aaa\dude.gif
	# exampleData\aaa\xyz\	
	
	# Forward and backward slashes are equivalent and either can be used..
	zipEntry = zip.FirstMatchingEntry("*/dude.gif")
	if (zipEntry != nil) 
		gifData = Chilkat::CkByteData.new()
		zipEntry.Inflate(gifData)
		
		# Upload the binary data directly to
		# an FTP server without ever having to write
		# an actual .zip on the local filesystem...
		ftp = Chilkat::CkFtp2.new()
		ftp.UnlockComponent("anything for 30-day trial")
		ftp.put_Hostname("www.chilkatsoft.com")
		ftp.put_Username("myLogin")
		ftp.put_Password("myPassword")
		success = ftp.Connect()
		if (success)
			ftp.ChangeRemoteDir("d2")
			remoteFilename = "dude.gif"
			success = ftp.PutFileFromBinaryData(remoteFilename,gifData)
			if (success)
				printf("Uploaded GIF image to FTP server!\n")
			else
				ftp.SaveLastError("ftpPutError.txt")
			end
		else
			ftp.SaveLastError("ftpError.txt")
		end	
	else
		printf("Failed to find hello.txt!\n")
	end
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end

