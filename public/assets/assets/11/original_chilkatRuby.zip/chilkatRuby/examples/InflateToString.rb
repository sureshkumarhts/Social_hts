# file: InflateToString.rb

require '../chilkat'

# Open a .zip, locate a specific file within the .zip and 
# inflate the contents directly into a string variable.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

success = zip.OpenZip("exampleData.zip")
if success
	# The zip in this example contains these files and directories:
	# exampleData\
	# exampleData\hamlet.xml
	# exampleData\123\
	# exampleData\aaa\
	# exampleData\123\hello.txt
	# exampleData\aaa\banner.gif
	# exampleData\aaa\dude.gif
	# exampleData\aaa\xyz\	
	
	# Forward and backward slashes are equivalent and either can be used..
	zipEntry = zip.FirstMatchingEntry("*/hello.txt")
	if (zipEntry != nil) 
		str = Chilkat::CkString.new()
		zipEntry.InflateToString2(str)
		printf("File contents:\n%s\n",str.getString())
	else
		printf("Failed to find hello.txt!\n")
	end
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end
