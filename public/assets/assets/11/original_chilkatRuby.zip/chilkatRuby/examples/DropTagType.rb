# file: DropTagType.rb

require '../chilkat'

# Demonstrates how specific HTML tags can be selected to be dropped
# during the HTML to XML conversion process.

htmlConv = Chilkat::CkHtmlToXml.new()
success = htmlConv.UnlockComponent("anything for 30-day trial")
if not success
	print "component is locked!"
	exit
end

html = "<html><body><span>This <b>is</b> a <i>test</i><hr></span></body></html>"
	
# First, call UndropTextFormattingTags to prevent the text formatting tags
# from being dropped by default.
htmlConv.UndropTextFormattingTags()

# We'll want to drop <hr>, <i>, and <span> tags:
htmlConv.DropTagType("hr")
htmlConv.DropTagType("i")
htmlConv.DropTagType("span")

# To convert, set the HTML and get the XML:
htmlConv.put_Html(html)
xml = htmlConv.xml()

print xml


#	The output is this:
#	
#	<?xml version="1.0" encoding="utf-8" ?>
#
#	<root>
#	    <html>
#	        <body>
#	            <text>This </text>
#	            <b>
#	                <text>is</text>
#	            </b>
#	            <text>a  test</text>
#	        </body>
#	    </html>
#	</root>	
			

