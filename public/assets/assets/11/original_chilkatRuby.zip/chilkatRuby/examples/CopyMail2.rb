# file: CopyMail2.rb

# Ruby script to download email and display information about each email.
# The purpose of this example is to show how to extract information from an email.

require '../chilkat'

# Create an instance of the mailman object for reading POP3 email.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your POP3 server's hostname and login/password
mailman.put_MailHost("mail.chilkatsoft.com")
mailman.put_PopUsername("myLogin")
mailman.put_PopPassword("myPassword")

# Download all the email in the mailbox without removing the email.
bundle = mailman.CopyMail()
if bundle == nil
	# Failed to download email.
	mailman.SaveLastError("errorLog.txt")
else	
	# Loop over each email, print the From address and Subject, recipients,
	# attachment information, and message bodies.
	numMessages = bundle.get_MessageCount()

	subject = Chilkat::CkString.new()
	from = Chilkat::CkString.new()
	recipient = Chilkat::CkString.new()
	filename = Chilkat::CkString.new()
	plainTextBody = Chilkat::CkString.new()
	htmlBody = Chilkat::CkString.new()

	for i in 0..(numMessages-1)
		email = bundle.GetEmail(i)

		# Get the email's subject and From address
		email.get_Subject(subject)
		email.get_From(from)		
		print "From:    " + from.getUtf8() + "\n"
		print "Subject: " + subject.getUtf8() + "\n"
		
		# Get the "To" recipients.
		numTo = email.get_NumTo()
		for j in 0..(numTo-1)
			email.GetTo(j,recipient)
			printf "TO: " + recipient.getUtf8() + "\n"
		end
		
		# Get the "CC" recipients.
		numCC = email.get_NumCC()
		for j in 0..(numCC-1)
			email.GetCC(j,recipient)
			print "CC: " + recipient.getUtf8() + "\n"
		end
		
		# Get the BCC recipients?  
		# No, can't do it.  BCC recipients are not present in the MIME source of the email.
		# There is no way for the To, CC, or other BCC recipients to see the other BCC recipients.
		# (Otherwise, it wouldn't be a "BLIND" Carbon Copy...)
		
		# Get the attachment filenames and sizes.
		numAttach = email.get_NumAttachments()
		for j in 0..(numAttach-1)
			email.GetAttachmentFilename(j,filename)
			fileSize = email.GetAttachmentSize(j)
			print "Attachment: " + filename.getUtf8() + ", " + fileSize.to_s() + " bytes\n"
		end
		
		# Does this email have a plain-text body?
		# If so, get it and print it.
		if (email.HasPlainTextBody())
			email.GetPlainTextBody(plainTextBody)
			print "Plain-Text Body:\n" + plainTextBody.getUtf8()
			print "\n-------------------------\n\n"
		end
		
		# Does this email have an HTML body?
		# If so, get the HTML source and print it.
		if (email.HasHtmlBody())
			email.GetHtmlBody(htmlBody)
			print "HTML Body:\n" + htmlBody.getUtf8()
			print "\n-------------------------\n\n"
		end
		
		print "\n"
	end
end

