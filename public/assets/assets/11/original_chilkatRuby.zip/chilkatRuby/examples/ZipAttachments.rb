# file: ZipAttachments.rb

require '../chilkat'

# Ruby script to email with attachments contained in a .zip.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a login, set username/password
# mailman.put_SmtpUsername("myUsername")
# mailman.put_SmtpPassword("myPassword")

# Create a simple email with attachments
email = Chilkat::CkEmail.new()
email.put_Subject("Sending email with zipped attachments from Ruby")
email.put_Body("This email was sent from a Ruby script")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

# Add attachments as in the previous Ruby example (EmailAttachments.rb)
contentType = Chilkat::CkString.new()
success = email.AddFileAttachment("exampleData/hamlet.xml",contentType)
email.AddStringAttachment("test1.txt","This string is the content of test1.txt")
email.AddStringAttachment2("test2.txt","This string is the content of test2.txt","iso-8859-1")

# You could send the email at this point in the code by calling mailman.SendEmail.
# If you did, your email would have 3 attachments: test1.txt, test2.txt, and hamlet.xml
# However, you could first call email.ZipAttachments like this:
email.ZipAttachments("myAttachments.zip")

# myAttachments.zip is the name of the attachment that will appear in the email.
# After calling ZipAttachments, your email will contain 1 attachment 
# (myAttachments.zip) and within it are three files: 
# test1.txt, test2.txt, and hamlet.xml.   

success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt")
end


