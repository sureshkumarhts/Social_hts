# file: StartTls.rb

# Ruby script to send email using SMTP STARTTLS.

# Connects to an SMTP server on the standard non-secure
# port 25 and issues a STARTTLS command to convert the connection
# to a secure SSL/TLS channel.

# One additional line of code is required to do this:
# you simply need to tell the mailman that you want STARTTLS
# by setting the StartTLS property = true.
	
# Note: When sending email using STARTTLS, *everything* is protected.
# If authentication is required, your login/password is sent securely.  
# The entire email, including attachments, is sent over SSL.
	

require '../chilkat'

# Create an instance of the mailman object for sending.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# Request STARTTLS
mailman.put_StartTLS(true)

# If your SMTP server requires a login, set login/password
#mailman.put_SmtpUsername("myLogin")
#mailman.put_SmtpPassword("myPassword")

# Create a simple email
email = Chilkat::CkEmail.new()
email.put_Subject("STARTTLS Ruby Scripting Example")
email.put_Body("This email was sent over a secure connection from a Ruby script")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
