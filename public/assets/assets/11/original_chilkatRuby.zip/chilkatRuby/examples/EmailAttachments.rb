# file: EmailAttachments.rb

require '../chilkat'

# Sends email with attachments in Ruby.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your SMTP server's hostname
mailman.put_SmtpHost("smtp.comcast.net")

# If your SMTP server requires a login, set username/password
# mailman.put_SmtpUsername("myUsername")
# mailman.put_SmtpPassword("myPassword")

# Create a simple email with attachments
email = Chilkat::CkEmail.new()
email.put_Subject("Sending email with attachments from Ruby")
email.put_Body("This email was sent from a Ruby script")
email.put_From("Chilkat Support <support@chilkatsoft.com>")

# Add a few recipients
email.AddTo("Matt","matt@chilkatsoft.com")
email.AddTo("TagTooga","admin@tagtooga.com")

# Attachments can be added from files or in-memory data.
# Returns true if the file was added successfully.  The content-type
# is returned in the 2nd argument.  This is for the benefit of programs
# that may need it, but most do not.
contentType = Chilkat::CkString.new()
success = email.AddFileAttachment("exampleData/hamlet.xml",contentType)

# You may add a text file attachment directly from a string in memory.
# AddStringAttachment2 allows for the charset encoding to be directly specified.
# AddStringAttachment automatically uses the utf-8 encoding for text file attachments.
email.AddStringAttachment("test1.txt","This string is the content of test1.txt")
email.AddStringAttachment2("test2.txt","This string is the content of test2.txt","iso-8859-1")

success = mailman.SendEmail(email)
if not success
	mailman.SaveLastError("lastError.txt");
end
