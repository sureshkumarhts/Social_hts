# file: xmlBinary.rb
# 
# Demonstrates how to embed binary data within an XML file.

require '../chilkat'

# The Chilkat XML parser for Ruby is freeware.  The code demonstrated in this
# example can be used in both commercial and non-commercial applications without 
# restriction.  

# Some Chilkat XML Ruby examples utilize these online XML data samples:
# http://www.chilkatsoft.com/xml-samples/bookstore.xml
# http://www.chilkatsoft.com/xml-samples/nutrition.xml
# http://www.chilkatsoft.com/xml-samples/pigs.xml
# http://www.chilkatsoft.com/xml-samples/plants.xml
# http://www.chilkatsoft.com/xml-samples/japanese.xml
# http://www.chilkatsoft.com/xml-samples/hamlet.xml
    
# Create a new XML document
xml = Chilkat::CkXml.new()
xml.put_Tag("myImages")

# Load a TIF file into a CkByteData object.
dataObj = Chilkat::CkByteData.new()
dataObj.loadFile("chilkatRuby.tif")

# Create a child node that will hold the image.
image1 = xml.NewChild("image","")
image1.AddAttribute("type","tif")
image1.AddAttribute("zipCompressed","no")
image1.AddAttribute("aesEncrypted","no")

# Add the binary content to the XML node as a Base64-encoded string.
encrypt = false
compress = false
password = ""
image1.SetBinaryContent(dataObj,compress,encrypt,password)

# Save the XML file.
xml.SaveXml("images.xml")

# The XML looks like this:
# <?xml version="1.0" encoding="utf-8" ?>
# <myImages>
# <image type="tif" zipCompressed="no" aesEncrypted="no">
# SUkqAAgAAAAPAP4ABAABAAAAAAAAAAABAwABAAAAZAAAAAEBAwABAAAAZAAAAAIBAwABAAAA
# CAAAAAMBAwABAAAAAQAAAAYBAwABAAAAAwAAABEBBAABAAAAcBgAABUBAwABAAAAAQAAABYB
# ...
# AwABAAAAZAAAABcBBAABAAAAECcAABoBBQABAAAAwgAAABsBBQABAAAAygAAACgBAwABAAAA
# UEg=
# </image>
# </myImages>


# Load the XML and extract the TIF image to a file.
xml2 = Chilkat::CkXml.new()
xml2.LoadXmlFile("images.xml")
imageNode = xml2.FirstChild()
dataObj2 = Chilkat::CkByteData.new()
# Make sure to pass the same settings for compression, encryption, and password.
imageNode.GetBinaryContent(dataObj2,compress,encrypt,password)
# Save the binary data to a file.
dataObj2.saveFile("chilkatRuby2.tif")

# Remove imageNode from the document.
imageNode.RemoveFromTree()

# The binary content can optionally be Zip compressed and/or 128-bit AES encrypted.
# Simply set the flags and password:
imageNode2 = xml2.NewChild("image","")
imageNode2.AddAttribute("type","tif")
imageNode2.AddAttribute("zipCompressed","yes")
imageNode2.AddAttribute("aesEncrypted","yes")

# Load a TIF file into a CkByteData object.
dataObj3 = Chilkat::CkByteData.new()
dataObj3.loadFile("chilkatRuby.tif")

encrypt = true
compress = true
password = "chilkat"
imageNode2.SetBinaryContent(dataObj3,compress,encrypt,password)

# Save the XML file.  The image in this XML document is encrypted and compressed.
xml2.SaveXml("images2.xml")
