# file: ZipFromMemory.rb

require '../chilkat'

# Create a .zip archive from in-memory data.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

zip.NewZip("fromMemory.zip")

str = ""
for i in 0 .. 100
	str = str + "abcdefghijklmnopqrstuvwxyz\n"
end
zip.AppendString("string1.txt",str)

str = ""
for i in 0 .. 100
	str = str + "1234567890\n"
end
zip.AppendString("string2.txt",str)

# Creates "fromMemory.zip" which contains two files:
# string1.txt and string2.txt
zip.WriteZipAndClose()

