# file: Unzip.rb

require '../chilkat'

# Simple example showing how to unzip a .zip file.
zip = Chilkat::CkZip.new()
zip.UnlockComponent("anything for 30-day trial")

success = zip.OpenZip("exampleData.zip")
if success
	# The zip in this example contains these files and directories:
	# exampleData\
	# exampleData\hamlet.xml
	# exampleData\123\
	# exampleData\aaa\
	# exampleData\123\hello.txt
	# exampleData\aaa\banner.gif
	# exampleData\aaa\dude.gif
	# exampleData\aaa\xyz\	
	
	# Returns -1 if error, otherwise returns the number of files and directories
	# unzipped.
	# In this example, Unzip will create the directory "unzipDir" in the current
	# working directory (if it does not already exist) and unzip into it.
	numUnzipped = zip.Unzip("unzipDir")
	printf "numUnzipped = %d\n",numUnzipped
else
	# Failed to open the .zip archive.
	zip.SaveLastError("openZipError.txt")
end
