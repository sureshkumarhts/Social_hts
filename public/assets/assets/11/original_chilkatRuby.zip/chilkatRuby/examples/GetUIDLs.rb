# file: GetUIDLs.rb

# Ruby script to get the UIDLs for the email messages in a mailbox.

require '../chilkat'

# Create an instance of the mailman object for reading POP3 email.
mailman = Chilkat::CkMailMan.new()
mailman.UnlockComponent("anything for 30-day trial")

# Set your POP3 server's hostname and login/password
mailman.put_MailHost("mail.chilkatsoft.com")
mailman.put_PopUsername("myLogin")
mailman.put_PopPassword("myPassword")

# Get the UIDLs for the mail in a POP3 mailbox.
# sa is a Chilkat::CkStringArray
sa = mailman.GetUidls()
if sa == nil
	errorText = Chilkat::CkString.new()
	mailman.LastErrorText(errorText)
	print errorText.getUtf8()
else
	# We have the UIDLs, print them.
	uidl = Chilkat::CkString.new()
	numStrings = sa.get_Count()
	for i in 0..(numStrings-1)
		sa.GetString(i,uidl)
		print uidl.getString() + "\n"
	end
end
